import { useMemo } from "react";
import * as THREE from "three";
import { LUNA_SITE } from "./lunaProgramme";
import { lunaMaterialFactories } from "./lunaMaterials";
import { useLightingMode } from "../engine";
import { mergedBoxGeometry, type BoxSpec } from "../engine/utils/geometryUtils";

// Phase 15C — after the anchor moved ~99m north to establish a credible
// Ahmadu Bello Way frontage (see lunaSite.ts's LUNA_SITE_ANCHOR note),
// the real Ahmadu Bello Way trunk-road carriageway itself now sits at
// approximately local (2.5, 45) per the re-projected OSM data (see
// src/luna/site/lunaRing2Data.ts) — a short, direct, one-segment
// connector reads correctly now (previously, at the old anchor, this
// reached a distant side street via a two-segment bend).
const ACCESS_CONNECTOR_POINTS: Array<[number, number]> = [
  [0, LUNA_SITE.depth / 2 + 18],
  [2.5, 45],
];

/** Ring 1 (conceptual Luna site, ~0-100m) immediate context: an arrival
 * driveway, forecourt lawn, boundary treatment, bollard lighting, and a
 * handful of taller palm clusters near the entrance. Everything here is
 * static (no fade/selection — it isn't part of the addressable twin
 * hierarchy), so it's plain meshes, not engine primitives.
 *
 * Phase 15B: this component used to also own an arbitrary west-facing
 * (-X) "waterfront" plane and six freestanding silhouette-block
 * placeholders standing in for an unspecified urban backdrop — both were
 * always non-geographic artistic choices (flagged as such in the Phase
 * 15A audit). Now that real Victoria Island context exists in every
 * direction (see ./site/LunaSiteContext.tsx's Ring 2 real OSM-derived
 * neighbours and Ring 3's art-directed horizon + south-facing water,
 * matching this site's actual heading — see lunaSite.ts), those two
 * pieces have been retired rather than left to visually conflict with
 * real geometry occupying the same space — removed here once Ring 2/3
 * were built as their visual replacement (Phase 15B report §6), subject
 * to the same regression pass as every other Phase 15B change. */
export function LunaEnvironment() {
  const drivewayMaterial = useMemo(() => lunaMaterialFactories.driveway(), []);
  const connectorRoadMaterial = useMemo(() => lunaMaterialFactories.contextRoad(), []);
  const connectorSidewalkMaterial = useMemo(() => lunaMaterialFactories.paving(), []);
  const connectorGeometry = useMemo(() => {
    const specs: BoxSpec[] = [];
    for (let i = 0; i < ACCESS_CONNECTOR_POINTS.length - 1; i++) {
      const [x1, z1] = ACCESS_CONNECTOR_POINTS[i];
      const [x2, z2] = ACCESS_CONNECTOR_POINTS[i + 1];
      const length = Math.hypot(x2 - x1, z2 - z1);
      const rotationY = Math.atan2(x2 - x1, z2 - z1);
      specs.push({ size: [6, 0.08, length], position: [(x1 + x2) / 2, 0.01, (z1 + z2) / 2], rotationY });
    }
    return mergedBoxGeometry(specs);
  }, []);
  const connectorSidewalkGeometry = useMemo(() => {
    const specs: BoxSpec[] = [];
    for (let i = 0; i < ACCESS_CONNECTOR_POINTS.length - 1; i++) {
      const [x1, z1] = ACCESS_CONNECTOR_POINTS[i];
      const [x2, z2] = ACCESS_CONNECTOR_POINTS[i + 1];
      const length = Math.hypot(x2 - x1, z2 - z1);
      const rotationY = Math.atan2(x2 - x1, z2 - z1);
      const dx = (x2 - x1) / length, dz = (z2 - z1) / length;
      // Perpendicular offset (right-hand side of travel) for a single
      // continuous sidewalk edge alongside the connector.
      const offX = dz * 4, offZ = -dx * 4;
      specs.push({
        size: [1.6, 0.05, length],
        position: [(x1 + x2) / 2 + offX, 0.015, (z1 + z2) / 2 + offZ],
        rotationY,
      });
    }
    return mergedBoxGeometry(specs);
  }, []);
  const palmTrunk = useMemo(() => new THREE.MeshStandardMaterial({ color: "#5b4636", roughness: 0.9 }), []);
  const palmFrond = useMemo(() => new THREE.MeshStandardMaterial({ color: "#3f6b3a", roughness: 0.85 }), []);
  const lawnMaterial = useMemo(() => lunaMaterialFactories.lawn(), []);
  const pavingMaterial = useMemo(() => lunaMaterialFactories.paving(), []);
  const boundaryMaterial = useMemo(() => lunaMaterialFactories.stone(), []);
  const bollardPostMaterial = useMemo(() => lunaMaterialFactories.darkAluminium(), []);
  const lightingMode = useLightingMode();
  const bollardLightMaterial = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#3a2c1a", emissive: "#ffb877", emissiveIntensity: lightingMode === "evening" ? 1.6 : 0.25 }),
    [lightingMode]
  );

  const palmSpots: Array<[number, number, number]> = [
    [-8, 0, LUNA_SITE.depth / 2 - 3],
    [8, 0, LUNA_SITE.depth / 2 - 3],
    [-16, 0, LUNA_SITE.depth / 2 - 8],
    [16, 0, LUNA_SITE.depth / 2 - 8],
  ];

  return (
    <group>
      {/* Forecourt lawn — a green setting for the arrival sequence, behind
          the driveway loop so the site reads as landscaped, not paved-over. */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, LUNA_SITE.depth / 2 + 14]} receiveShadow>
        <planeGeometry args={[LUNA_SITE.width - 6, 16]} />
        <primitive object={lawnMaterial} attach="material" />
      </mesh>

      {/* Arrival driveway / drop-off loop, leading to the entrance at +z,
          with a planted median suggesting a real loop rather than a single
          straight apron. */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.03, LUNA_SITE.depth / 2 + 8]} receiveShadow>
        <planeGeometry args={[14, 20]} />
        <primitive object={drivewayMaterial} attach="material" />
      </mesh>
      <mesh position={[0, 0.25, LUNA_SITE.depth / 2 + 8]} castShadow>
        <boxGeometry args={[4, 0.5, 10]} />
        <primitive object={lawnMaterial} attach="material" />
      </mesh>
      {[[-2.2, LUNA_SITE.depth / 2 + 4], [2.2, LUNA_SITE.depth / 2 + 12]].map(([x, z], i) => (
        <mesh key={`median-${i}`} position={[x, 0.55, z]} castShadow material={palmFrond}>
          <coneGeometry args={[0.6, 1, 5]} />
        </mesh>
      ))}

      {/* Pedestrian path from the drop-off loop toward the entrance canopy,
          distinct paving from the vehicular driveway surface. */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[7.5, -0.02, LUNA_SITE.depth / 2 + 6]} receiveShadow>
        <planeGeometry args={[2.4, 16]} />
        <primitive object={pavingMaterial} attach="material" />
      </mesh>

      {/* Phase 15C — access connector: a short, direct link from the
          site's own drop-off apron to the real Ahmadu Bello Way
          carriageway itself (see ACCESS_CONNECTOR_POINTS above). This is
          the visual transition the brief asks for between the fictional
          Ring 1 parcel and the geographically grounded Ring 2 environment
          — Luna's own road surface literally continues into the real
          street network rather than the two simply floating near each
          other. */}
      <mesh geometry={connectorGeometry} material={connectorRoadMaterial} receiveShadow={false} raycast={() => null} />
      <mesh geometry={connectorSidewalkGeometry} material={connectorSidewalkMaterial} receiveShadow={false} raycast={() => null} />

      {/* Low boundary treatment along both site edges. */}
      {[-LUNA_SITE.width / 2 + 1, LUNA_SITE.width / 2 - 1].map((x, i) => (
        <mesh key={`boundary-${i}`} position={[x, 0.35, 0]} receiveShadow castShadow material={boundaryMaterial}>
          <boxGeometry args={[0.6, 0.7, LUNA_SITE.depth + 30]} />
        </mesh>
      ))}

      {/* Bollard lights along the driveway edge — subtle by day, a warm
          site-lighting accent in evening mode (Phase 11 section 14). */}
      {[-5, -1.5, 2, 5.5].map((z, i) => (
        <group key={`bollard-${i}`} position={[6, 0, LUNA_SITE.depth / 2 + 4 + z]}>
          <mesh position={[0, 0.35, 0]} castShadow material={bollardPostMaterial}>
            <cylinderGeometry args={[0.08, 0.08, 0.7, 8]} />
          </mesh>
          <mesh position={[0, 0.72, 0]} material={bollardLightMaterial}>
            <sphereGeometry args={[0.09, 8, 8]} />
          </mesh>
        </group>
      ))}

      {palmSpots.map(([x, , z], i) => (
        <group key={i} position={[x, 0, z]}>
          <mesh position={[0, 2.2, 0]} castShadow material={palmTrunk}>
            <cylinderGeometry args={[0.18, 0.28, 4.4, 6]} />
          </mesh>
          {[0, 1, 2, 3, 4].map((f) => (
            <mesh
              key={f}
              position={[Math.cos((f / 5) * Math.PI * 2) * 0.9, 4.4, Math.sin((f / 5) * Math.PI * 2) * 0.9]}
              rotation={[0.5, (f / 5) * Math.PI * 2, 0]}
              castShadow
              material={palmFrond}
            >
              <coneGeometry args={[0.35, 2.6, 4]} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}
